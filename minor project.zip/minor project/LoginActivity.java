package com.example.greentrack;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Find the login button by its ID and set a click listener
        findViewById(R.id.loginButton1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle login button click
                if (validateAndSubmit()) // call for validation
                {
                    goToMenuActivity(); // Call the method to go to MainActivity
                }

            }
        });
    }

    // Method to navigate to MainActivity
    private void goToMenuActivity() {
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }

    private boolean validateAndSubmit() {
        // Perform validation for all fields here
        // If validation succeeds, proceed with the submission
        // Otherwise, display validation errors to the user
        EditText nameEditText = findViewById(R.id.editText2);
        EditText passwordEditText = findViewById(R.id.editText3);
        String name = nameEditText.getText().toString();
        if (TextUtils.isEmpty(name))
        {
            // Show an error message or highlight the field
            nameEditText.setError("Username should not be empty");
            return false;
        }
        String password = passwordEditText.getText().toString();
        if (password.length() < 8)
        {
            // Show an error message or highlight the field
            passwordEditText.setError("Password must be at least 8 characters long");
            return false;
        }
        return true;
    }

}
