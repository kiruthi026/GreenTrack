package com.example.greentrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class IntroActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.intro);

            // Find the login button by its ID and set a click listener
            findViewById(R.id.loginButton).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle login button click
                    goToLoginActivity(); // Call the method to go to MainActivity   1   `

                }
            });
        }

        // Method to navigate to MainActivity
        private void goToLoginActivity() {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

    }
