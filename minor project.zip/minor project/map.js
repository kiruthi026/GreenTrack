//Initialize the map
function initMap() {
    var coordinates = { lat: 11.017363, lng: 76.958885 }; // Replace with your coordinates
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 12,
        center: coordinates
    });

    // Add a marker for the coordinates
    var marker = new google.maps.Marker({
        position: coordinates,
        map: map,
        title: 'My Marker'
    });
}