package com.example.greentrack;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.textclassifier.ConversationActions;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.Request;
import okio.BufferedSink;


public class ContentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content);
        findViewById(R.id.sbutton).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v)
            {
                if (validateAndSubmit())
                {
                    apiPush();
                }
            }
        });
    }

    private void goToIntroActivity() {
        Intent intent = new Intent(this, IntroActivity.class);
        startActivity(intent);
    }
    private boolean validateAndSubmit() {
        // Perform validation for all fields here
        // If validation succeeds, proceed with the submission
        // Otherwise, display validation errors to the user
        EditText nameEditText = findViewById(R.id.editText2);
        EditText vnameEditText = findViewById(R.id.editText3);
        EditText dnameEditText = findViewById(R.id.editTextDate);
        EditText tnameEditText = findViewById(R.id.editText4);
        String name = nameEditText.getText().toString();
        //String vname = vnameEditText.getText().toString();
        if (TextUtils.isEmpty(name))
        {
            // Show an error message or highlight the field
            nameEditText.setError(" Tree Name should not be empty");
            return false;
        }
        String dname = dnameEditText.getText().toString();
        if (TextUtils.isEmpty(dname))
        {
            // Show an error message or highlight the field
            dnameEditText.setError(" Tree Name should not be empty");
            return false;
        }
        String vname = vnameEditText.getText().toString();
        if (TextUtils.isEmpty(vname))
        {
            // Show an error message or highlight the field
            vnameEditText.setError("Date should not be empty");
            return false;
        }
        String tname = tnameEditText.getText().toString();
        if (TextUtils.isEmpty(tname))
        {
            // Show an error message or highlight the field
            tnameEditText.setError("Tree variety should not be empty");
            return false;
        }
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void apiPush() {
        // Create a request body with the JSON data
        EditText nameEditText = findViewById(R.id.editText2);
        EditText vnameEditText = findViewById(R.id.editText3);
//EditText dnameEditText = findViewById(R.id.editTextDate);
        EditText tnameEditText = findViewById(R.id.editText4);
        EditText latEditText = findViewById(R.id.editText8);
        EditText lonEditText = findViewById(R.id.editText7);
        OkHttpClient client = new OkHttpClient();
        ;

        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        JSONObject formData = new JSONObject();

// Create a JSON object with your form data
        try {
            formData.put("village", vnameEditText.getText().toString());
            formData.put("name", nameEditText.getText().toString());
            formData.put("variety", tnameEditText.getText().toString());
            formData.put("Latitude", latEditText.getText().toString());
            formData.put("Longitude", lonEditText.getText().toString());
            // Add other form fields as needed
        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestBody MyCustomRequestBody = (RequestBody) RequestBody.create(JSON, formData.toString());

// Create an HTTP request

        //ConversationActions.Request request = new ConversationActions.Request.Builder()
        //   .url("https://www.greentrack.site/api/v1/planting.php/trees")
        //  .post(requestBody)
        // .build();

        Request request = new Request.Builder()
                .url("https://www.greentrack.site/api/v1/planting.php/trees")
                .post(MyCustomRequestBody)
                .build();



// Send the request asynchronously

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Handle request failure (e.g., network issues)
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run()
                    {
                        // Show an error message to the user (e.g., using Toast)
                        Toast.makeText(getApplicationContext(), "Request failed. Please check your network connection.", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                // Handle the API response here
                if (response.isSuccessful()) {
                    // API request was successful
                    String responseData = response.body().string();
                    // Process the response data as needed
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Process the response data as needed and update the UI
                            // Example: Update UI elements or show a success message
                            Toast.makeText(getApplicationContext(), "Success: " + responseData, Toast.LENGTH_SHORT).show();
                            goToIntroActivity();
                        }
                    });
                } else {
                    // API request failed (handle errors)
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Show an error message to the user (e.g., using Toast)
                            Toast.makeText(getApplicationContext(), "API request failed. Please try again later.", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

    }


    private static class MyCustomRequestBody extends okhttp3.RequestBody {
        public static <MediaType> RequestBody create(MediaType json, String toString) {
            return null;
        }

        @Nullable
        @Override
        public MediaType contentType() {
            return null;
        }

        @Override
        public void writeTo(@NonNull BufferedSink bufferedSink) throws IOException {

        }
    }
}