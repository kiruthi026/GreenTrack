<?php
// Database connection configuration
$servername = "localhost";
$username = "greentra_harri";
$password = "Lavi@1234";
$dbname = "greentra_eses_forestry";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch coordinates from the database
$sql = "SELECT latitude, longitude FROM tree_planting";
$result = $conn->query($sql);

// Initialize an array to store coordinates
$coordinates = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $coordinates[] = $row;
    }
}

// Close the database connection
$conn->close();
?>

<!-- JavaScript to render the map with dynamic coordinates -->
<script>
var map;
function initMap() {
    var mapOptions = {
        center: { lat: 17.123184, lng: 79.208824 }, // Default center
        zoom: 5,
    };
    map = new google.maps.Map(document.getElementById("map"), mapOptions);

    // Loop through the coordinates array and add markers to the map
    <?php foreach ($coordinates as $coord): ?>
        var marker = new google.maps.Marker({
            position: { lat: <?= $coord['latitude'] ?>, lng: <?= $coord['longitude'] ?> },
            map: map,
        });
    <?php endforeach; ?>
}

function showInfo(marker) {
    // Create an info window or a custom HTML element to display information
    var content = "<div><h3>Location Information</h3><p>Additional information goes here.</p></div>";

    // Create an info window
    var infoWindow = new google.maps.InfoWindow({
        content: content,
    });

    // Open the info window at the marker's position
    infoWindow.open(map, marker);
}
</script>