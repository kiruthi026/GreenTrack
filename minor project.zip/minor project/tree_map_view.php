<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tree Location</title>
	<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>
    <!-- Google Map will be displayed here -->
	<div class="topnav">
  <a href="#home">Home</a>
  <a href="users.php">Users</a>
  <a href="treeplanting.php">Tree Planting Report</a>
  <a class="active" href="#tree_map_view">Map View</a>
  <a href="logout.php">Logout</a>
</div>

<div style="padding-left:16px">
  <h2>Map View</h2>
</div>
    <div id="map" style="height: 600px; width: 100%;"></div>

    <!-- Include the Google Maps JavaScript API with your API key -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_Bf2jgnudwjea6f4TzCclqNQl30JPt2k&callback=initMap" async defer></script>

    <!-- Your JavaScript code to load coordinates on the map -->
    <?php include "mapview.php"; ?>
</body>
</html>
