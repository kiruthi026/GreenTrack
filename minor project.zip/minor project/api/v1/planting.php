<?php
include("connection.php");
$db = new dbObj();
$connection =  $db->getConnstring();
$request_method=$_SERVER["REQUEST_METHOD"];
$trees_endpoint = $base_url . "/trees";
switch($request_method)
  {
    case 'GET':
      // Retrive Products
      if(!empty($_GET["id"]))
      {
        $id=intval($_GET["id"]);
		$url = $trees_endpoint . "?id=" . $id;
        get_trees($id);
      }
      else
      {
        get_trees();
      }
      break;
    default:
      // Invalid Request Method
      header("HTTP/1.0 405 Method Not Allowed");
      break;
	case 'POST':
// Insert Product
    insert_trees();
break;
  }
  function get_trees()
  {
    global $connection;
    $query="SELECT * FROM tree_planting";
    $response=array();
    $result=mysqli_query($connection, $query);
    while($row=mysqli_fetch_array($result))
    {
      $response[]=$row;
    }
    header('Content-Type: application/json');
    echo json_encode($response);
  }
  function insert_trees()
  {
    global $connection;

    $data = json_decode(file_get_contents('php://input'), true);
    $tree_village=$data["village"];
    $tree_name=$data["name"];
    $tree_variety=$data["variety"];
	$tree_lat=$data["Latitude"];
	$tree_long=$data["Longitude"];
    //echo $query="INSERT INTO tree_planting SET village='".$tree_village."', name='".$tree_name."', variety='".$tree_variety."'", Latitude='".$tree_lat."', Longitude='".$tree_long."'";
	$query = "INSERT INTO tree_planting (village, name, variety, Latitude, Longitude)
          VALUES ('$tree_village', '$tree_name', '$tree_variety', '$tree_lat', '$tree_long')";

    if(mysqli_query($connection, $query))
    {
      $response=array(
        'status' => 1,
        'status_message' =>'Tree Added Successfully.'
      );
    }
    else
    {
      $response=array(
        'status' => 0,
        'status_message' =>'Tree Addition Failed.'
      );
    }
    header('Content-Type: application/json');
    echo json_encode($response);
  }
?>
