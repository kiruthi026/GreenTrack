RewriteEngine On # Turn on the rewriting engine
RewriteRule ^planting/?$ planting.php [NC,L]
RewriteRule ^planting/([0-9]+)/?$ planting.php?id=$1 [NC,L]