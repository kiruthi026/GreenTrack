<!DOCTYPE html>
<html>
<head>
    
</head>
<body>
  <div class="topnav">
  <a href="welcome.php">Home</a>
  <a class="active" href="#users">Users</a>
  <a href="treeplanting.php">Tree Planting Report</a>
  <a href="tree_map_view.php">Map View</a>
  <a href="logout.php">Logout</a>
</div>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 16px;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
</style>
<div style="padding-left:16px">
  <h2>Users List</h2>
</div>

    <?php
    // Establish a MySQL database connection
    $conn = mysqli_connect("localhost", "greentra_harri", "Lavi@1234", "greentra_eses_forestry");

    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // SQL query to fetch data from the database
    $sql = "SELECT id, username FROM users";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Create an HTML table to display the data
        echo "<table border='1'>";
		echo "<tr><th>ID</th><th>Username</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['username'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No records found in the database.";
    }

    // Close the database connection
    mysqli_close($conn);
    ?>

</body>
</html>